Data / Residual / Signal Container
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: lisatools.datacontainer.DataResidualArray
    :members:
    :show-inheritance:

Analysis Container
~~~~~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: lisatools.analysiscontainer.AnalysisContainer
    :members:
    :show-inheritance: