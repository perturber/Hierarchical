LISA Analysis Tools (``lisatools``)
===================================

Run large-scale and small-scale LISA data analysis
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
