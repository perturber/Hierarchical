#!/usr/bin/env bash

./scripts/generate-changelog.bash
