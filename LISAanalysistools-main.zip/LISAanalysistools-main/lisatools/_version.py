__version__ = '1.0.13'
__copyright__ = "Michael L. Katz 2024"
__name__ = "lisaanalysistools"
__author__ = "Michael L. Katz"
